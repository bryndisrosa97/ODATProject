package is.hi.hbv601g.odat.entities;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity (tableName = "lists")
public class TList {

    @PrimaryKey (autoGenerate = true)
    private int id;

    @ColumnInfo (name = "listname")
    private String mListName;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getListName() {
        return mListName;
    }

    public void setListName(String listName) {
        mListName = listName;
    }
}