package is.hi.hbv601g.odat.daos;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;
import java.util.Optional;

import is.hi.hbv601g.odat.entities.TFolder;

@Dao
public interface TFolderDao {

    @Insert
    public void addTFolder(TFolder tFolder);

    @Delete
    public void deleteTFolder(TFolder tFolder);

    @Query("SELECT * FROM tFolders")
    public List<TFolder> getAllTFolders();

    @Query("SELECT * FROM tFolders " + "WHERE mFolderName LIKE :folderName")
    public TFolder getTFolderByName(String folderName);
}
