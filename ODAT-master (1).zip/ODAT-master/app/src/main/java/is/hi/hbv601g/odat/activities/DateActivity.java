package is.hi.hbv601g.odat.activities;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.room.Room;

import com.google.android.material.navigation.NavigationView;

import java.util.ArrayList;
import java.util.List;

import is.hi.hbv601g.odat.ODATDatabase;
import is.hi.hbv601g.odat.R;
import is.hi.hbv601g.odat.entities.Task;

public class DateActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    private TextView mDate;
    private DrawerLayout mDrawerLayout;
    private NavigationView mNavigationView;
    private static ODATDatabase mODATDatabase;
    private Toolbar mToolbar;
    private List<Task> mTasks;
    private String mInfo;
    private ListView mListView;
    private LinearLayout mLayoutDayView;
    private FrameLayout mLayoutEvent;

    ArrayList<String> mTaskNameOfDay = new ArrayList<String>();
    ArrayList<String> mTaskTimeOfDay = new ArrayList<String>();
    ArrayList<String> mTaskFolder = new ArrayList<String>();

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dayview_layout);
        mDrawerLayout = findViewById(R.id.drawerLayout);
        mNavigationView = findViewById(R.id.nav_view);
        mToolbar = findViewById(R.id.toolbar);

        setSupportActionBar(mToolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        mNavigationView.bringToFront();

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, mDrawerLayout, mToolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        mDrawerLayout.addDrawerListener(toggle);
        toggle.syncState();
        mNavigationView.setNavigationItemSelectedListener(this);

        Intent incomingIntent = getIntent();
        String date = incomingIntent.getStringExtra("date");
        mDate = (TextView) findViewById(R.id.date);
        mDate.setText(date);

        mODATDatabase = Room.databaseBuilder(getApplicationContext(), ODATDatabase.class, "ODAT").allowMainThreadQueries().build();

        mLayoutDayView = (LinearLayout) findViewById(R.id.dayview_container);
        mLayoutEvent = (FrameLayout) findViewById(R.id.event_container);

        mTasks = mODATDatabase.mTaskDao().getAllTasks();

        mInfo = "";

        mListView = findViewById(R.id.list);

        for (Task task : mTasks) {
            String taskName = task.getTitle();
            String start = task.getStartTime();
            String end = task.getEndTime();
            String folderName = task.getFolderName();
            String stringStart = start;
            String[] partsOfStart = stringStart.split("-");
            String dateOfTaskStart = partsOfStart[0];
            String dateOfTaskStartNew = dateOfTaskStart.replace(".", "");
            String dateClockStart = partsOfStart[1];
            String[] partsOfStartNew = date.split("/");
            String dateYear = partsOfStartNew[0];
            String dateMonth = partsOfStartNew[1];
            String dateDay = partsOfStartNew[2];
            String newDate = dateDay + dateMonth + dateYear;
            String stringEnd = end;
            String[] partsOfEnd = stringEnd.split("-");
            String dateOfTaskEnd = partsOfEnd[0];
            String dateClockEnd = partsOfEnd[1];

            String[] partsOfDateStart = dateOfTaskStart.split("\\.");
            String[] partsOfDateEnd = dateOfTaskEnd.split("\\.");

            String timer;

            String partsOfDateTheDayStart = partsOfDateStart[0];
            String partsOfDateTheDayEnd = partsOfDateEnd[0];

            String partsOfDateMonthStart = partsOfDateStart[1];
            String partsOfDateMonthEnd = partsOfDateEnd[1];

            if (dateOfTaskStartNew.equals(newDate)) {
                mInfo =  " " + dateClockStart + " " + dateClockEnd + " " + taskName + " " + folderName ;
                if (partsOfDateTheDayStart.equals(partsOfDateTheDayEnd)){
                    timer =  dateClockStart +  " - " + dateClockEnd + " " ;
                } else {
                    timer = "" + partsOfDateTheDayStart + "/" + partsOfDateMonthStart + " " +  dateClockStart +  "  -  " + partsOfDateTheDayEnd + "/" + partsOfDateMonthEnd + " " + dateClockEnd + " ";
                }
                mTaskNameOfDay.add(taskName);
                mTaskTimeOfDay.add(timer);
                mTaskFolder.add((folderName));
            }
        }

        EventListAdapter adapter = new EventListAdapter(this, mTaskNameOfDay, mTaskTimeOfDay, mTaskFolder);

        mListView.setAdapter(adapter);
        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                int itemPosition = position;
                String itemValue = (String) mListView.getItemAtPosition(position);
            }
        });
    }

    @Override
    public void onBackPressed() {
        if (mDrawerLayout.isDrawerOpen(GravityCompat.START)) {
            mDrawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        switch (menuItem.getItemId()) {
            case R.id.nav_home:
                Intent homeIntent = new Intent(DateActivity.this, MainActivity.class);
                startActivity(homeIntent);
                break;
            case R.id.nav_tasks:
                Intent tasksIntent = new Intent(DateActivity.this, TaskActivity.class);
                startActivity(tasksIntent);
                break;
            case R.id.nav_folders:
                Intent foldersIntent = new Intent(DateActivity.this, FolderActivity.class);
                startActivity(foldersIntent);
                break;
            case R.id.nav_lists:
                Intent listsIntent = new Intent(DateActivity.this, ListActivity.class );
                startActivity(listsIntent);
                break;
            case R.id.nav_quotes:
                Intent quotesIntent = new Intent(DateActivity.this, QuoteActivity.class);
                startActivity(quotesIntent);
                break;
            case R.id.nav_goals:
                Intent goalsIntent = new Intent(DateActivity.this, GoalActivity.class);
                startActivity(goalsIntent);
                break;
        }
        mDrawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }
}