package is.hi.hbv601g.odat.entities;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.PrimaryKey;
@Entity (tableName = "tFolders")
public class TFolder {

    @NonNull
    @PrimaryKey
    private String mFolderName;

    public String getFolderName() {
        return mFolderName;
    }

    public void setFolderName(String folderName) {
        mFolderName = folderName;
    }
}
