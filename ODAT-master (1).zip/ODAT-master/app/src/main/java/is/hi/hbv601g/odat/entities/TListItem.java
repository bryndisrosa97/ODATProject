package is.hi.hbv601g.odat.entities;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.PrimaryKey;

@Entity(tableName = "tlistitems", foreignKeys = {@ForeignKey(entity = TList.class, parentColumns = "id", childColumns = "tlistid", onDelete = ForeignKey.CASCADE)})
public class TListItem {

    @PrimaryKey (autoGenerate = true)
    private int id;

    @ColumnInfo (name = "listitemname")
    private String mListItemName;

    @NonNull
    @ColumnInfo (name = "tlistid")
    private int mListId;

    @ColumnInfo (name = "checked")
    private boolean mChecked;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getListItemName() {
        return mListItemName;
    }

    public void setListItemName(String listItemName) {
        mListItemName = listItemName;
    }

    public int getListId() {
        return mListId;
    }

    public void setListId(int listId) {
        mListId = listId;
    }

    public boolean isChecked() {
        return mChecked;
    }

    public void setChecked(boolean checked) {
        mChecked = checked;
    }

    //public TListItem(String listItemName) {
    //mListItemName = listItemName;
    //}


}