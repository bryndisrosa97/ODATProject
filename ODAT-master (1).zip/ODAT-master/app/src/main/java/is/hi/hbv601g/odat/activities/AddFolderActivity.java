package is.hi.hbv601g.odat.activities;

import android.content.Intent;
import android.os.Bundle;

import android.text.TextUtils;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.room.Room;

import com.google.android.material.navigation.NavigationView;

import java.util.List;

import is.hi.hbv601g.odat.ODATDatabase;
import is.hi.hbv601g.odat.R;
import is.hi.hbv601g.odat.entities.TFolder;

public class AddFolderActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    private static ODATDatabase mODATDatabase;
    private EditText mTFolderText;
    private Button mAddTFolderButton;
    private List<TFolder> tFolders;
    private DrawerLayout mDrawerLayout;
    private NavigationView mNavigationView;
    private Toolbar mToolbar;
    private TextView mRequiredTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_add_folder);
        mDrawerLayout = findViewById(R.id.drawerLayout);
        mNavigationView = findViewById(R.id.nav_view);
        mToolbar = findViewById(R.id.toolbar);

        setSupportActionBar(mToolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        mNavigationView.bringToFront();

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, mDrawerLayout, mToolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        mDrawerLayout.addDrawerListener(toggle);
        toggle.syncState();
        mNavigationView.setNavigationItemSelectedListener(this);
        mNavigationView.setCheckedItem(R.id.nav_folders);

        mODATDatabase = Room.databaseBuilder(getApplicationContext(), ODATDatabase.class, "ODAT").allowMainThreadQueries().build();
        tFolders = mODATDatabase.mTFolderDao().getAllTFolders();

        mAddTFolderButton = (Button) findViewById(R.id.add_folder_button);
        mTFolderText = (EditText) findViewById(R.id.folder_txt);
        mRequiredTextView = (TextView) findViewById(R.id.add_failed_textView);

        mAddTFolderButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String tFolderName = mTFolderText.getText().toString().toLowerCase();
                TFolder folderAlreadyExists = mODATDatabase.mTFolderDao().getTFolderByName(tFolderName);

                if (TextUtils.isEmpty(tFolderName)) {
                    mRequiredTextView.setText("Name of folder is required");
                } else if (folderAlreadyExists != null){
                    mRequiredTextView.setText("Folder already exists");
                } else {
                    TFolder tFolder = new TFolder();
                    tFolder.setFolderName(tFolderName);

                    mODATDatabase.mTFolderDao().addTFolder(tFolder);
                    tFolderAddedText();

                    mTFolderText.setText("");
                    mRequiredTextView.setText("");

                    Intent folderIntent = new Intent(AddFolderActivity.this, FolderActivity.class);
                    startActivity(folderIntent);
                }
            }
        });
    }

    private void tFolderAddedText() {
        Toast.makeText(this, R.string.tFolder_added_toast, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onBackPressed() {
        if (mDrawerLayout.isDrawerOpen(GravityCompat.START)) {
            mDrawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        switch (menuItem.getItemId()) {
            case R.id.nav_home:
                Intent homeIntent = new Intent(AddFolderActivity.this, MainActivity.class);
                startActivity(homeIntent);
                break;
            case R.id.nav_tasks:
                Intent tasksIntent = new Intent(AddFolderActivity.this, TaskActivity.class);
                startActivity(tasksIntent);
                break;
            case R.id.nav_folders:
                Intent foldersIntent = new Intent(AddFolderActivity.this, FolderActivity.class );
                startActivity(foldersIntent);
                break;
            case R.id.nav_lists:
                Intent listsIntent = new Intent(AddFolderActivity.this, ListActivity.class );
                startActivity(listsIntent);
                break;
            case R.id.nav_quotes:
                Intent quotesIntent = new Intent(AddFolderActivity.this, QuoteActivity.class);
                startActivity(quotesIntent);
                break;
            case R.id.nav_goals:
                Intent goalsIntent = new Intent(AddFolderActivity.this, GoalActivity.class);
                startActivity(goalsIntent);
                break;
        }
        mDrawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }
}