package is.hi.hbv601g.odat.daos;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

import is.hi.hbv601g.odat.entities.TListItem;

@Dao
public interface TlistitemDao {
    @Insert
    public void addTlistitem(TListItem tlistitem);

    @Delete
    public void deleteTlistitem(TListItem tlistitem);

    @Query("UPDATE tlistitems SET checked =:mChecked WHERE id =:tlistItemId ")
    public void updateChecked(boolean mChecked, int tlistItemId);

    @Query("SELECT * FROM tlistitems")
    public List<TListItem> getAllTlistitems();

    @Query("SELECT * FROM tlistitems" + " WHERE tlistid LIKE :tlistId")
    public List<TListItem> getTlistitemByListId(int tlistId);

    @Query("SELECT checked FROM tlistitems WHERE id =:tlistitemid")
    public Boolean isChecked(int tlistitemid);


}
