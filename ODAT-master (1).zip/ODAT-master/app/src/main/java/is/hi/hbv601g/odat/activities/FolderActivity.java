package is.hi.hbv601g.odat.activities;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.room.Room;

import android.util.DisplayMetrics;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;

import com.google.android.material.navigation.NavigationView;

import java.util.List;

import is.hi.hbv601g.odat.ODATDatabase;
import is.hi.hbv601g.odat.R;
import is.hi.hbv601g.odat.entities.TFolder;

public class FolderActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    private static ODATDatabase mODATDatabase;
    private Button mFolderButton;
    private Button mAddNewFolderButton;
    private Button mSelectedFolderButton;
    private Button mDeleteFolderButton;
    private List<TFolder> tFolders;
    private int mFolderId;
    private DrawerLayout mDrawerLayout;
    private NavigationView mNavigationView;
    private Toolbar mToolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_folder);
        mDrawerLayout = findViewById(R.id.drawerLayout);
        mNavigationView = findViewById(R.id.nav_view);
        mToolbar = findViewById(R.id.toolbar);

        setSupportActionBar(mToolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        mNavigationView.bringToFront();

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, mDrawerLayout, mToolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        mDrawerLayout.addDrawerListener(toggle);
        toggle.syncState();
        mNavigationView.setNavigationItemSelectedListener(this);
        mNavigationView.setCheckedItem(R.id.nav_folders);

        mODATDatabase = Room.databaseBuilder(getApplicationContext(), ODATDatabase.class, "ODAT").allowMainThreadQueries().build();

        tFolders = mODATDatabase.mTFolderDao().getAllTFolders();

        LinearLayout linearLayout = (LinearLayout) findViewById(R.id.folder_activity);

        mFolderId = 0;
        for (TFolder tFolder : tFolders) {
            LinearLayout newLinearLayout = new LinearLayout(this);
            linearLayout.addView(newLinearLayout);
            LayoutParams layoutParams = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);

            mFolderButton = new Button(this);
            mDeleteFolderButton = new Button(this);

            DisplayMetrics dm = new DisplayMetrics();
            this.getWindow().getWindowManager().getDefaultDisplay().getMetrics(dm);
            int width = dm.widthPixels;
            mFolderButton.setWidth(width*7/8);
            mDeleteFolderButton.setWidth(width*1/8);

            String tFolderName = tFolder.getFolderName();
            mFolderButton.setId(mFolderId);
            int id = mFolderButton.getId();
            mFolderButton.setText(tFolderName);

            mDeleteFolderButton.setBackground(this.getResources().getDrawable(R.drawable.delete));

            newLinearLayout.addView(mFolderButton, layoutParams);
            newLinearLayout.addView(mDeleteFolderButton, layoutParams);

            TFolder mTFolder = mODATDatabase.mTFolderDao().getTFolderByName(tFolderName);

            mSelectedFolderButton = (Button) findViewById(id);
            mSelectedFolderButton.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    Intent mFolderTasksIntent = new Intent(FolderActivity.this, FolderTasks.class);
                    mFolderTasksIntent.putExtra("mSelectedFolder", tFolderName);
                    startActivity(mFolderTasksIntent);
                }
            });

            mDeleteFolderButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mODATDatabase.mTFolderDao().deleteTFolder(mTFolder);
                    Intent mFoldersIntent = getIntent();
                    finish();
                    startActivity(mFoldersIntent);
                }
            });
            mFolderId++;
        }

        mAddNewFolderButton = (Button) findViewById(R.id.add_new_folder_button);
        mAddNewFolderButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent mAddFolderIntent = new Intent(FolderActivity.this, AddFolderActivity.class );
                startActivity(mAddFolderIntent);
            }
        });
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        switch (menuItem.getItemId()) {
            case R.id.nav_home:
                Intent homeIntent = new Intent(FolderActivity.this, MainActivity.class);
                startActivity(homeIntent);
                break;
            case R.id.nav_tasks:
                Intent tasksIntent = new Intent(FolderActivity.this, TaskActivity.class);
                startActivity(tasksIntent);
                break;
            case R.id.nav_folders:
                break;
            case R.id.nav_lists:
                Intent listsIntent = new Intent(FolderActivity.this, ListActivity.class );
                startActivity(listsIntent);
                break;
            case R.id.nav_quotes:
                Intent quotesIntent = new Intent(FolderActivity.this, QuoteActivity.class);
                startActivity(quotesIntent);
                break;
            case R.id.nav_goals:
                Intent goalsIntent = new Intent(FolderActivity.this, GoalActivity.class);
                startActivity(goalsIntent);
                break;
        }
        mDrawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }
}