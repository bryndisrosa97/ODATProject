package is.hi.hbv601g.odat.activities;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.room.Room;

import com.google.android.material.navigation.NavigationView;

import java.util.ArrayList;
import java.util.List;

import is.hi.hbv601g.odat.ODATDatabase;
import is.hi.hbv601g.odat.R;
import is.hi.hbv601g.odat.entities.Goal;
import is.hi.hbv601g.odat.entities.Task;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    private static ODATDatabase mODATDatabase;
    private List<Goal> mGoals;
    public CalendarView mCalendarView;
    private DrawerLayout mDrawerLayout;
    private NavigationView mNavigationView;
    private Toolbar mToolbar;
    private ArrayList<String> mGoalsName = new ArrayList<String>();
    private ArrayList<String> mFolderTime = new ArrayList<String>();
    private ArrayList<Goal> mGoal = new ArrayList<Goal>();
    private ListView mListView;
    private List<Task> mTasks;
    private Button mWeekButton;

    @SuppressLint("ResourceAsColor")
    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mDrawerLayout = findViewById(R.id.drawerLayout);
        mNavigationView = findViewById(R.id.nav_view);
        mToolbar = findViewById(R.id.toolbar);

        setSupportActionBar(mToolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        mNavigationView.bringToFront();

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, mDrawerLayout, mToolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        mDrawerLayout.addDrawerListener(toggle);
        toggle.syncState();
        mNavigationView.setNavigationItemSelectedListener(this);
        mNavigationView.setCheckedItem(R.id.nav_home);

        mWeekButton = (Button) findViewById(R.id.weekbutton);
        mWeekButton.setBackgroundColor(getResources().getColor(R.color.HotPink));
        mWeekButton.setHighlightColor(R.color.HotPink);

        mODATDatabase = Room.databaseBuilder(getApplicationContext(), ODATDatabase.class, "ODAT").allowMainThreadQueries().build();

        mCalendarView = (CalendarView) findViewById(R.id.calendarView);

        mWeekButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mWeekButton.setBackgroundColor(getResources().getColor(R.color.HotPink));
                Intent weekOverviewIntent = new Intent(MainActivity.this, WeekActivity.class);
                startActivity(weekOverviewIntent );
            }
        });

        mGoals = mODATDatabase.mGoalDao().getAllGoals();
        mTasks = mODATDatabase.mTaskDao().getAllTasks();

        mListView = findViewById(R.id.list);

        for (Goal goal : mGoals) {
            String goalName = goal.getDescription();
            mGoalsName.add(goalName);
            mGoal.add(goal);
        }

        GoalListAdapter adapter = new GoalListAdapter(this, mGoalsName, mGoal);
        mListView.setAdapter(adapter);

        for (Task task : mTasks) {
            String timeStart = task.getStartTime();
            String[] parts = timeStart.split("-");
            String date = parts[0];
            mFolderTime.add(date);
            mFolderTime.forEach(System.out::println);
        }

        mCalendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {
                String date = year + "/" + (month + 1) + "/" + dayOfMonth;

                Intent intent = new Intent(MainActivity.this, DateActivity.class);
                intent.putExtra("date", date);
                startActivity(intent);
            }
        });
    }

    @Override
    public void onBackPressed() {
        if (mDrawerLayout.isDrawerOpen(GravityCompat.START)) {
            mDrawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        switch (menuItem.getItemId()) {
            case R.id.nav_home:
                break;
            case R.id.nav_tasks:
                Intent tasksIntent = new Intent(MainActivity.this, TaskActivity.class);
                startActivity(tasksIntent);
                break;
            case R.id.nav_folders:
                Intent foldersIntent = new Intent(MainActivity.this, FolderActivity.class);
                startActivity(foldersIntent);
                break;
            case R.id.nav_lists:
                Intent listsIntent = new Intent(MainActivity.this, ListActivity.class );
                startActivity(listsIntent);
                break;
            case R.id.nav_quotes:
                Intent quotesIntent = new Intent(MainActivity.this, QuoteActivity.class);
                startActivity(quotesIntent);
                break;
            case R.id.nav_goals:
                Intent goalsIntent = new Intent(MainActivity.this, GoalActivity.class);
                startActivity(goalsIntent);
                break;
        }
        mDrawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }
}