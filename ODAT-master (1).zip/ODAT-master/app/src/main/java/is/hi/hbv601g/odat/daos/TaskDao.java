package is.hi.hbv601g.odat.daos;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

import is.hi.hbv601g.odat.entities.Goal;
import is.hi.hbv601g.odat.entities.TFolder;
import is.hi.hbv601g.odat.entities.Task;

@Dao
public interface TaskDao {

    @Insert
    public void addTask(Task task);

    @Delete
    public void deleteTask(Task task);

    @Query("SELECT * FROM tasks")
    public List<Task> getAllTasks();

    @Query("SELECT * FROM tasks WHERE taskTitle LIKE :title AND startTime LIKE :start AND " +
            "endTime LIKE :end AND folder_name LIKE :folder")
    public Task getTaskId(String title, String start, String end, String folder);

    @Query("SELECT * FROM tasks WHERE Id IN(:id) ")
    public Task findTaskById(int id);

    @Query("SELECT * FROM tasks " + "WHERE folder_name LIKE :folderName")
    public List<Task> getTasksByFolderName(String folderName);
}