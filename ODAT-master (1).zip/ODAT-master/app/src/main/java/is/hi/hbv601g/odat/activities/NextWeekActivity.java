package is.hi.hbv601g.odat.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.room.Room;

import com.google.android.material.navigation.NavigationView;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import is.hi.hbv601g.odat.ODATDatabase;
import is.hi.hbv601g.odat.R;
import is.hi.hbv601g.odat.entities.Task;

public class NextWeekActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    private DrawerLayout mDrawerLayout;
    private NavigationView mNavigationView;
    private Toolbar mToolbar;
    private static ODATDatabase mODATDatabase;
    private DateFormat mFormat = new SimpleDateFormat("d/M/yyyy");
    private List<Task> mTasks;
    private TextView mDateTextView;
    private TextView mWeekTextView;
    private Button mButton;
    private Calendar mCalendar = Calendar.getInstance();
    private ListView mMondayListView;
    private ListView mTuesdayListView;
    private ListView mWednesdayListView;
    private ListView mThursdayListView;
    private ListView mFridayListView;
    private ListView mSaturdayListView;
    private ListView mSundayListView;

    // Monday
    ArrayList<String> mTaskNameOfDayMonday = new ArrayList<String>();
    ArrayList<String> mTaskTimeOfDayMonday = new ArrayList<String>();
    ArrayList<String> mTaskFolderNameMonday = new ArrayList<String>();

    // Tuesday
    ArrayList<String> mTaskNameOfDayTuesday = new ArrayList<String>();
    ArrayList<String> mTaskTimeOfDayTuesday = new ArrayList<String>();
    ArrayList<String> mTaskFolderNameTuesday = new ArrayList<String>();

    // Wednesday
    ArrayList<String> mTaskNameOfDayWednesday = new ArrayList<String>();
    ArrayList<String> mTaskTimeOfDayWednesday = new ArrayList<String>();
    ArrayList<String> mTaskFolderNameWednesday = new ArrayList<String>();

    // Thursday
    ArrayList<String> mTaskNameOfDayThursday = new ArrayList<String>();
    ArrayList<String> mTaskTimeOfDayThursday = new ArrayList<String>();
    ArrayList<String> mTaskFolderNameThursday = new ArrayList<String>();

    // Friday
    ArrayList<String> mTaskNameOfDayFriday = new ArrayList<String>();
    ArrayList<String> mTaskTimeOfDayFriday = new ArrayList<String>();
    ArrayList<String> mTaskFolderNameFriday = new ArrayList<String>();

    // Saturday
    ArrayList<String> mTaskNameOfDaySaturday = new ArrayList<String>();
    ArrayList<String> mTaskTimeOfDaySaturday = new ArrayList<String>();
    ArrayList<String> mTaskFolderNameSaturday = new ArrayList<String>();

    // Sunday
    ArrayList<String> mTaskNameOfDaySunday = new ArrayList<String>();
    ArrayList<String> mTaskTimeOfDaySunday = new ArrayList<String>();
    ArrayList<String> mTaskFolderNameSunday = new ArrayList<String>();

    private String mMonday;
    private String mTuesday;
    private String mWednesday;
    private String mThursday;
    private String mFriday;
    private String mSaturday;
    private String mSunday;

    int mWeekNumber;

    private EventWeekListAdapter adapterMonday;
    private EventWeekListAdapter adapterTuesday;
    private EventWeekListAdapter adapterWednesday;
    private EventWeekListAdapter adapterThursday;
    private EventWeekListAdapter adapterFriday;
    private EventWeekListAdapter adapterSaturday;
    private EventWeekListAdapter adapterSunday;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nextweek);
        mDrawerLayout = findViewById(R.id.drawerLayout);
        mNavigationView = findViewById(R.id.nav_view);
        mToolbar = findViewById(R.id.toolbar);

        setSupportActionBar(mToolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        mNavigationView.bringToFront();

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, mDrawerLayout, mToolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        mDrawerLayout.addDrawerListener(toggle);
        toggle.syncState();
        mNavigationView.setNavigationItemSelectedListener(this);

        mODATDatabase = Room.databaseBuilder(getApplicationContext(), ODATDatabase.class, "ODAT").allowMainThreadQueries().build();

        mCalendar.setFirstDayOfWeek(Calendar.MONDAY);
        mCalendar.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);

        Date c = Calendar.getInstance().getTime();
        SimpleDateFormat df = new SimpleDateFormat("dd-MMM-yyyy", Locale.getDefault());
        String formattedDate = df.format(c);

        mDateTextView = (TextView) findViewById(R.id.date);
        mWeekTextView = (TextView) findViewById(R.id.theweek);
        mButton = (Button) findViewById(R.id.button);
        mMondayListView = (ListView) findViewById(R.id.list_next_monday);
        mTuesdayListView = (ListView) findViewById(R.id.list_next_tuesday);
        mWednesdayListView = (ListView) findViewById(R.id.list_next_wednesday);
        mThursdayListView = (ListView) findViewById(R.id.list_next_thursday);
        mFridayListView = (ListView) findViewById(R.id.list_next_friday);
        mSaturdayListView = (ListView) findViewById(R.id.list_next_saturday);
        mSundayListView = (ListView) findViewById(R.id.list_next_sunday);

        mButton.setBackgroundColor(getResources().getColor(R.color.HotPink));
        mMondayListView.setAdapter(adapterMonday);
        mDateTextView.setText(formattedDate);

        Intent iin = getIntent();
        Bundle b = iin.getExtras();

        if(b != null)
        {
          mWeekNumber = (int) b.get("wno");
        }

        drawUpTheWeek(mWeekNumber);

        mButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mButton.setBackgroundColor(getResources().getColor(R.color.HotPink));
                mWeekNumber = mWeekNumber +1;
                System.out.println("numer á vik" + mWeekNumber);
                String[] daysofweek = getWeekDates(mWeekNumber);
                System.out.println(Arrays.toString(daysofweek));
                drawUpTheWeek(mWeekNumber);
            }
        });
    }

    private void drawUpTheWeek(int weekNumber) {

        String[] daysOfWeek = getWeekDates(weekNumber);

        mTasks = mODATDatabase.mTaskDao().getAllTasks();

        mTaskNameOfDayMonday.clear();
        mTaskTimeOfDayMonday.clear();
        mTaskFolderNameMonday.clear();

        mTaskNameOfDayTuesday.clear();
        mTaskTimeOfDayTuesday.clear();
        mTaskFolderNameTuesday.clear();

        mTaskNameOfDayWednesday.clear();
        mTaskTimeOfDayWednesday.clear();
        mTaskFolderNameWednesday.clear();

        mTaskNameOfDayThursday.clear();
        mTaskTimeOfDayThursday.clear();
        mTaskFolderNameThursday.clear();

        mTaskNameOfDayFriday.clear();
        mTaskTimeOfDayFriday.clear();
        mTaskFolderNameFriday.clear();

        mTaskNameOfDaySaturday.clear();
        mTaskTimeOfDaySaturday.clear();
        mTaskFolderNameSaturday.clear();

        mTaskNameOfDaySunday.clear();
        mTaskTimeOfDaySunday.clear();
        mTaskFolderNameSunday.clear();

        String man = daysOfWeek[0];
        String sun = daysOfWeek[6];

        String theWeek = man + " - " + sun;
        mWeekTextView.setText(theWeek);

        mMonday =daysOfWeek[2].replace("/", "");
        mTuesday = daysOfWeek[1].replace("/", "");
        mWednesday = daysOfWeek[2].replace("/", "");
        mThursday = daysOfWeek[3].replace("/", "");
        mFriday = daysOfWeek[4].replace("/", "");
        mSaturday = daysOfWeek[5].replace("/", "");
        mSunday = daysOfWeek[6].replace("/", "");

        for (Task task : mTasks) {
            String taskName = task.getTitle();
            String taskStartTime = task.getStartTime();
            String taskFolderName = task.getFolderName();
            String[] partsStart = taskStartTime.split("-");
            String dateOfTaskStart = partsStart[0]; // 004
            String dateOfTaskStartReplace = dateOfTaskStart.replace(".", "");
            String taskEndTime = task.getEndTime();
            String[] partsEnd = taskEndTime.split("-");
            String dateOfTaskEnd = partsEnd[0]; // 004
            String dateOfTaskEndReplace = dateOfTaskEnd.replace(".", "");
            String taskTime = taskStartTime + " " + taskEndTime;

            if (dateOfTaskStartReplace.equals(mMonday) || dateOfTaskEndReplace.equals(mMonday) ) {
                mTaskNameOfDayMonday.add(taskName);
                mTaskTimeOfDayMonday.add(taskTime);
                mTaskFolderNameMonday.add(taskFolderName);

            } else if (dateOfTaskStartReplace.equals(mTuesday) || dateOfTaskEndReplace.equals(mTuesday) ) {
                mTaskNameOfDayTuesday.add(taskName);
                mTaskTimeOfDayTuesday.add(taskTime);
                mTaskFolderNameTuesday.add(taskFolderName);

            } else if (dateOfTaskStartReplace.equals(mWednesday) || dateOfTaskEndReplace.equals(mWednesday) ) {
                mTaskNameOfDayWednesday.add(taskName);
                mTaskTimeOfDayWednesday.add(taskTime);
                mTaskFolderNameWednesday.add(taskFolderName);

            } else if (dateOfTaskStartReplace.equals(mThursday) || dateOfTaskEndReplace.equals(mThursday) ) {
                mTaskNameOfDayThursday.add(taskName);
                mTaskTimeOfDayThursday.add(taskTime);
                mTaskFolderNameThursday.add(taskFolderName);

            } else if (dateOfTaskStartReplace.equals(mFriday) || dateOfTaskEndReplace.equals(mFriday) ) {
                mTaskNameOfDayFriday.add(taskName);
                mTaskTimeOfDayFriday.add(taskTime);
                mTaskFolderNameFriday.add(taskFolderName);

            } else if (dateOfTaskStartReplace.equals(mSaturday) || dateOfTaskEndReplace.equals(mSaturday) ) {
                mTaskNameOfDaySaturday.add(taskName);
                mTaskTimeOfDaySaturday.add(taskTime);
                mTaskFolderNameSaturday.add(taskFolderName);

            } else if (dateOfTaskStartReplace.equals(mSunday) || dateOfTaskEndReplace.equals(mSunday) ) {
                mTaskNameOfDaySunday.add(taskName);
                mTaskTimeOfDaySunday.add(taskTime);
                mTaskFolderNameSunday.add(taskFolderName);

            } else {
            }
        }

        adapterMonday = new EventWeekListAdapter(this, mTaskNameOfDayMonday, mTaskTimeOfDayMonday, mTaskFolderNameMonday);
        mMondayListView.setAdapter(adapterMonday);
        getListViewSize(mMondayListView);

        adapterTuesday = new EventWeekListAdapter(this, mTaskNameOfDayTuesday, mTaskTimeOfDayTuesday, mTaskFolderNameTuesday);
        mTuesdayListView.setAdapter(adapterTuesday);
        getListViewSize(mTuesdayListView);

        adapterWednesday = new EventWeekListAdapter(this, mTaskNameOfDayWednesday, mTaskTimeOfDayWednesday, mTaskFolderNameWednesday);
        mWednesdayListView.setAdapter(adapterWednesday);
        getListViewSize(mWednesdayListView);

        adapterThursday = new EventWeekListAdapter(this, mTaskNameOfDayThursday, mTaskTimeOfDayThursday, mTaskFolderNameThursday);
        mThursdayListView.setAdapter(adapterThursday);
        getListViewSize(mThursdayListView);

        adapterFriday = new EventWeekListAdapter(this, mTaskNameOfDayFriday, mTaskTimeOfDayFriday, mTaskFolderNameFriday);
        mFridayListView.setAdapter(adapterFriday);
        getListViewSize(mFridayListView);

        adapterSaturday = new EventWeekListAdapter(this, mTaskNameOfDaySaturday, mTaskTimeOfDaySaturday, mTaskFolderNameSaturday);
        mSaturdayListView.setAdapter(adapterSaturday);
        getListViewSize(mSaturdayListView);

        adapterSunday = new EventWeekListAdapter(this, mTaskNameOfDaySunday, mTaskTimeOfDaySunday, mTaskFolderNameSunday);
        mSundayListView.setAdapter(adapterSunday);
        getListViewSize(mSundayListView);
    }

    @Override
    public void onBackPressed() {
        if (mDrawerLayout.isDrawerOpen(GravityCompat.START)) {
            mDrawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    public String[] getWeekDates(int week) {
        String[] daysOfWeek = new String[7];
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
        calendar.set(Calendar.WEEK_OF_MONTH, week);
        for (int i = 0; i < 7; i++) {
            daysOfWeek[i] = mFormat.format(calendar.getTime());
            calendar.add(Calendar.DAY_OF_MONTH, 1);
        }
        return daysOfWeek;
    }

    public static void getListViewSize(ListView myListView) {
        EventWeekListAdapter myListAdapter = (EventWeekListAdapter) myListView.getAdapter();
        if (myListAdapter == null) {
            return;
        }
        int totalHeight = 0;
        for (int size = 0; size < myListAdapter.getCount(); size++) {
            View listItem = myListAdapter.getView(size, null, myListView);
            listItem.measure(0, 0);
            totalHeight += listItem.getMeasuredHeight();
        }
        ViewGroup.LayoutParams params=myListView.getLayoutParams();
        params.height = totalHeight + (myListView.getDividerHeight() * (myListAdapter.getCount() - 1));
        myListView.setLayoutParams(params);
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        switch (menuItem.getItemId()) {
            case R.id.nav_home:
                Intent homeIntent = new Intent(NextWeekActivity.this, MainActivity.class);
                startActivity(homeIntent);
                break;
            case R.id.nav_tasks:
                Intent tasksIntent = new Intent(NextWeekActivity.this, TaskActivity.class);
                startActivity(tasksIntent);
                break;
            case R.id.nav_folders:
                Intent foldersIntent = new Intent(NextWeekActivity.this, FolderActivity.class);
                startActivity(foldersIntent);
                break;
            case R.id.nav_lists:
                Intent listsIntent = new Intent(NextWeekActivity.this, ListActivity.class );
                startActivity(listsIntent);
                break;
            case R.id.nav_quotes:
                Intent quotesIntent = new Intent(NextWeekActivity.this, QuoteActivity.class );
                startActivity(quotesIntent);
                break;
            case R.id.nav_goals:
                Intent goalsIntent = new Intent(NextWeekActivity.this, GoalActivity.class);
                startActivity(goalsIntent);
                break;
        }
        mDrawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }
}
