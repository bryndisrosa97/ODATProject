package is.hi.hbv601g.odat.activities;

import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;

import android.text.TextUtils;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.room.Room;

import com.google.android.material.navigation.NavigationView;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.TimeZone;

import is.hi.hbv601g.odat.ODATDatabase;
import is.hi.hbv601g.odat.R;
import is.hi.hbv601g.odat.entities.TFolder;
import is.hi.hbv601g.odat.entities.Task;


public class TaskActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    private ArrayList<PendingIntent> intentArray = new ArrayList<PendingIntent>();
    private Button mAddTaskButton;
    private Calendar mCurrCalendar;
    private CheckBox mNotifyCheckBox;
    private CheckBox mRepeatNotificationCheckbox;
    private DatePickerDialog mStartDatePicker;
    private DatePickerDialog mEndDatePicker;
    private DrawerLayout mDrawerLayout;
    private EditText mEndDateEditText;
    private EditText mEndTimeEditText;
    private EditText mTaskTitleText;
    private EditText mStartDateEditText;
    private EditText mStartTimeEditText;
    private int mDayToday;
    private int mEndTimeDay;
    private int mEndTimeHour;
    private int mEndTimeMinute;
    private int mEndTimeMonth;
    private int mEndTimeYear;
    private int mHourToday;
    private int mMinuteToday;
    private int mMonthToday;
    private int mNotifyId;
    private int mStartTimeDay;
    private int mStartTimeHour;
    private int mStartTimeMinute;
    private int mStartTimeMonth;
    private int mStartTimeYear;
    private int mYearToday;
    private Integer mSelectedNotification;
    private List<TFolder> mTFolders;
    private NavigationView mNavigationView;
    private static ODATDatabase mODATDatabase;
    public static PendingIntent mContentIntent;
    private Spinner mAddFolderSpinner;
    private Spinner mNotifySpinner;
    private Spinner mRepeatNotificationSpinner;
    private String mContentText;
    private String mNotificationMinutesString;
    private final String mOccurrence = "On occurrence";
    private final String mOneDay = "one day before";
    private final String mOneHour = "1 hour before";
    private String mRepeatNotificationString;
    private String mSelectedNotificationString;
    private final String mTenMin = "10 min before";
    private TextView mNotifyTextView;
    private TextView mRepeatNotificationTextView;
    private TextView mRequiredTextView;
    private TimePickerDialog mEndTimePicker;
    private TimePickerDialog mStartTimePicker;
    private Toolbar mToolbar;

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_task);
        mDrawerLayout = findViewById(R.id.drawerLayout);
        mNavigationView = findViewById(R.id.nav_view);
        mToolbar = findViewById(R.id.toolbar);

        setSupportActionBar(mToolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        mNavigationView.bringToFront();

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, mDrawerLayout, mToolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        mDrawerLayout.addDrawerListener(toggle);
        toggle.syncState();
        mNavigationView.setNavigationItemSelectedListener(this);
        mNavigationView.setCheckedItem(R.id.nav_tasks);

        mODATDatabase = Room.databaseBuilder(getApplicationContext(), ODATDatabase.class, "ODAT").allowMainThreadQueries().build();

        mTaskTitleText = (EditText) findViewById(R.id.taskTitleText);
        mAddFolderSpinner = (Spinner) findViewById(R.id.folderSpinner);

        mTFolders = mODATDatabase.mTFolderDao().getAllTFolders();
        String[] folderItems = new String[mTFolders.size()];
        for(int i = 0; i < mTFolders.size(); i++) {
            String tFolderName = mTFolders.get(i).getFolderName();
            folderItems[i] = tFolderName;
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, folderItems);
        mAddFolderSpinner.setAdapter(adapter);

        mCurrCalendar = Calendar.getInstance();
        mCurrCalendar.setTimeZone(TimeZone.getTimeZone("Iceland"));

        mStartDateEditText =(EditText) findViewById(R.id.startDateEditText);
        mStartDateEditText.setInputType(InputType.TYPE_NULL);

        mEndDateEditText =(EditText) findViewById(R.id.endDateEditText);
        mEndDateEditText.setInputType(InputType.TYPE_NULL);

        initializeDate();
        mStartDateEditText.setText(mStartTimeDay + "/" + (mStartTimeMonth + 1) + "/" + mStartTimeYear);
        mEndDateEditText.setText(mEndTimeDay + "/" + (mEndTimeMonth + 1) + "/" + mEndTimeYear);

        Calendar startDateCalendar = Calendar.getInstance();
        mStartDateEditText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startDateCalendar.setTimeZone(TimeZone.getTimeZone("Iceland"));
                mStartTimeDay = startDateCalendar.get(Calendar.DAY_OF_MONTH);
                mStartTimeMonth = startDateCalendar.get(Calendar.MONTH);
                mStartTimeYear = startDateCalendar.get(Calendar.YEAR);
                mStartDatePicker = new DatePickerDialog(TaskActivity.this,
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                                mStartDateEditText.setText((dayOfMonth) + "/" + (monthOfYear + 1) + "/" + year);
                                TaskActivity.this.mStartTimeYear = year;
                                TaskActivity.this.mStartTimeMonth = monthOfYear;
                                TaskActivity.this.mStartTimeDay = dayOfMonth;
                                startDateCalendar.set(Calendar.YEAR, mStartTimeYear);
                                startDateCalendar.set(Calendar.MONTH, mStartTimeMonth);
                                startDateCalendar.set(Calendar.DAY_OF_MONTH, mStartTimeDay);
                                mEndTimeYear = startDateCalendar.get(Calendar.YEAR);
                                mEndTimeMonth = startDateCalendar.get(Calendar.MONTH);
                                mEndTimeDay = startDateCalendar.get(Calendar.DAY_OF_MONTH);
                                mEndDateEditText.setText(mEndTimeDay + "/" + (mEndTimeMonth + 1) + "/" + mEndTimeYear);
                            }
                        }, mStartTimeYear, mStartTimeMonth, mStartTimeDay);
                mStartDatePicker.show();
            }
        });

        Calendar endDateCalendar = Calendar.getInstance();
        mEndDateEditText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                endDateCalendar.setTimeZone(TimeZone.getTimeZone("Iceland"));
                mEndTimeDay = endDateCalendar.get(Calendar.DAY_OF_MONTH);
                mEndTimeMonth = endDateCalendar.get(Calendar.MONTH);
                mEndTimeYear = endDateCalendar.get(Calendar.YEAR);
                // date picker dialog
                mEndDatePicker = new DatePickerDialog(TaskActivity.this,
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                                mEndDateEditText.setText(dayOfMonth + "/" + (monthOfYear + 1) + "/" + year);
                                TaskActivity.this.mEndTimeYear = year;
                                TaskActivity.this.mEndTimeMonth = monthOfYear;
                                TaskActivity.this.mEndTimeDay = dayOfMonth;
                                endDateCalendar.set(Calendar.YEAR, mEndTimeYear);
                                endDateCalendar.set(Calendar.MONTH, mEndTimeMonth);
                                endDateCalendar.set(Calendar.DAY_OF_MONTH, mEndTimeDay);
                            }
                        }, mEndTimeYear, mEndTimeMonth, mEndTimeDay);
                mEndDatePicker.getDatePicker().setMinDate(startDateCalendar.getTimeInMillis());
                mEndDatePicker.show();
            }
        });

        mStartTimeEditText =(EditText) findViewById(R.id.startTimeEditText);
        mStartTimeEditText.setInputType(InputType.TYPE_NULL);
        showCorrectTime(mStartTimeHour, mStartTimeMinute, "start");
        Calendar startTimeCalendar = Calendar.getInstance();
        mStartTimeEditText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startTimeCalendar.setTimeZone(TimeZone.getTimeZone("Iceland"));
                mStartTimeHour = startTimeCalendar.get(Calendar.HOUR_OF_DAY);
                mStartTimeMinute = startTimeCalendar.get(Calendar.MINUTE);
                mStartTimePicker = new TimePickerDialog(TaskActivity.this,
                        new TimePickerDialog.OnTimeSetListener() {
                            @Override
                            public void onTimeSet(TimePicker tp, int chosenHour, int chosenMinute) {
                                showCorrectTime(chosenHour,chosenMinute,"start");
                                TaskActivity.this.mStartTimeHour =chosenHour;
                                TaskActivity.this.mStartTimeMinute = chosenMinute;
                            }
                        }, mStartTimeHour, mStartTimeMinute, true);
                mStartTimePicker.show();
            }
        });

        mEndTimeEditText =(EditText) findViewById(R.id.endTimeEditText);
        mEndTimeEditText.setInputType(InputType.TYPE_NULL);
        showCorrectTime(mEndTimeHour, mEndTimeMinute,"end");
        Calendar endTimeCalendar = Calendar.getInstance();
        mEndTimeEditText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                endTimeCalendar.setTimeZone(TimeZone.getTimeZone("Iceland"));
                mEndTimeHour = endTimeCalendar.get(Calendar.HOUR_OF_DAY);
                mEndTimeMinute = endTimeCalendar.get(Calendar.MINUTE);
                mEndTimePicker = new TimePickerDialog(TaskActivity.this,
                        new TimePickerDialog.OnTimeSetListener() {
                            @Override
                            public void onTimeSet(TimePicker tp, int chosenHour, int chosenMinute) {
                                showCorrectTime(chosenHour, chosenMinute, "end");
                                TaskActivity.this.mEndTimeHour =chosenHour;
                                TaskActivity.this.mEndTimeMinute = chosenMinute;
                            }
                        }, mEndTimeHour, mEndTimeMinute, true);
                mEndTimePicker.show();
            }
        });

        mNotifyCheckBox = findViewById(R.id.notifyCheckbox);
        mNotifyTextView = findViewById(R.id.notifyTextView);
        mNotifySpinner = findViewById(R.id.notifySpinner);
        mRepeatNotificationCheckbox = findViewById(R.id.repeatNotificationCheckbox);
        mNotifyCheckBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (mNotifyCheckBox.isChecked()) {
                    mNotifyTextView.setVisibility(buttonView.VISIBLE);
                    mNotifySpinner.setVisibility(buttonView.VISIBLE);
                    mRepeatNotificationCheckbox.setVisibility(buttonView.VISIBLE);
                }
                else {
                    mNotifyTextView.setVisibility(buttonView.INVISIBLE);
                    mNotifySpinner.setVisibility(buttonView.INVISIBLE);
                    mRepeatNotificationCheckbox.setVisibility(buttonView.INVISIBLE);
                }
            }
        });

        String[] notifyItems = {mOccurrence, mTenMin, mOneHour, mOneDay};
        ArrayAdapter<String> notifyAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, notifyItems);
        mNotifySpinner.setAdapter(notifyAdapter);

        mRepeatNotificationTextView = findViewById(R.id.repeatNotificationTextView);
        mRepeatNotificationSpinner = findViewById(R.id.repeatNotificationSpinner);
        mRepeatNotificationCheckbox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (mRepeatNotificationCheckbox.isChecked()) {
                    mRepeatNotificationTextView.setVisibility(buttonView.VISIBLE);
                    mRepeatNotificationSpinner.setVisibility(buttonView.VISIBLE);
                } else {
                    mRepeatNotificationTextView.setVisibility(buttonView.INVISIBLE);
                    mRepeatNotificationSpinner.setVisibility(buttonView.INVISIBLE);
                }
            }
        });

        String[] repeatItems = {"daily", "weekly"};
        ArrayAdapter<String> repeatAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, repeatItems);
        mRepeatNotificationSpinner.setAdapter(repeatAdapter);

        mRequiredTextView = (TextView) findViewById(R.id.add_failed_textView);
        mAddTaskButton = findViewById(R.id.add_task_button);

        mAddTaskButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String taskName = mTaskTitleText.getText().toString();
                String selectedFolderName = mAddFolderSpinner.getSelectedItem().toString();
                String startTime = mStartTimeDay + "." + (mStartTimeMonth + 1) + "." + mStartTimeYear + "-" + mStartTimeHour + ":" + mStartTimeMinute;
                String endTime = mEndTimeDay + "." + (mEndTimeMonth + 1) + "." + mEndTimeYear + "-" + mEndTimeHour + ":" + mEndTimeMinute;

                if (TextUtils.isEmpty(taskName)||TextUtils.isEmpty(selectedFolderName)) {
                    mRequiredTextView.setText(R.string.task_requirements);
                } else if (mStartTimeDay == mEndTimeDay && mStartTimeMonth == mEndTimeMonth &&
                        mStartTimeYear == mEndTimeYear && mStartTimeHour == mEndTimeHour &&
                        mStartTimeMinute > mEndTimeMinute || mStartTimeDay == mEndTimeDay &&
                        mStartTimeMonth == mEndTimeMonth && mStartTimeYear == mEndTimeYear &&
                        mStartTimeHour > mEndTimeHour){
                    mRequiredTextView.setText(R.string.time_constraint);
                } else {
                    if (mNotifyCheckBox.isChecked()) {
                        mSelectedNotificationString = mNotifySpinner.getSelectedItem().toString();
                        if (mRepeatNotificationCheckbox.isChecked()) {
                            mRepeatNotificationString = mRepeatNotificationSpinner.getSelectedItem().toString();
                        } else {
                            mRepeatNotificationString = null;
                        }
                    } else {
                        mSelectedNotificationString = null;
                    }

                    Task task = new Task();
                    task.setTitle(taskName);
                    task.setStartTime(startTime);
                    task.setEndTime(endTime);
                    task.setFolderName(selectedFolderName);
                    task.setNotification(mSelectedNotificationString);
                    task.setRepeatNotification(mRepeatNotificationString);

                    mODATDatabase.mTaskDao().addTask(task);
                    taskAddedText();

                    if (mNotifyCheckBox.isChecked()) {
                        Task taskID = mODATDatabase.mTaskDao().getTaskId(taskName, startTime, endTime, selectedFolderName);
                        mSelectedNotification = checkNotifyValue(mSelectedNotificationString);
                        mContentText = taskName + mNotificationMinutesString;
                        mNotifyId = taskID.getId();

                        ReminderBroadcast.setId(mNotifyId);

                        Intent activityIntent = new Intent(TaskActivity.this, WeekActivity.class);
                        mContentIntent = PendingIntent.getActivity(TaskActivity.this, 0, activityIntent, 0);

                        Intent broadcastIntent = new Intent(TaskActivity.this, ReminderBroadcast.class);
                        broadcastIntent.putExtra("toastMessage", mContentText);
                        PendingIntent pendingIntent = PendingIntent.getBroadcast(TaskActivity.this, mNotifyId, broadcastIntent, PendingIntent.FLAG_UPDATE_CURRENT);

                        AlarmManager alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);

                        Calendar calendar = Calendar.getInstance();
                        calendar.setTimeZone(TimeZone.getTimeZone("Iceland"));
                        calendar.setTimeInMillis(System.currentTimeMillis());
                        calendar.set(Calendar.YEAR, mStartTimeYear);
                        calendar.set(Calendar.MONTH, mStartTimeMonth);
                        calendar.set(Calendar.DAY_OF_MONTH, mStartTimeDay);
                        calendar.set(Calendar.HOUR_OF_DAY, mStartTimeHour);
                        calendar.set(Calendar.MINUTE, mStartTimeMinute);

                        if (mRepeatNotificationCheckbox.isChecked()) {
                            if (mRepeatNotificationString.equals("daily")) {
                                alarmManager.setRepeating(AlarmManager.RTC_WAKEUP,
                                        calendar.getTimeInMillis() - 1000 * mSelectedNotification,
                                        AlarmManager.INTERVAL_DAY,
                                        pendingIntent);
                            } else {
                                alarmManager.setRepeating(AlarmManager.RTC_WAKEUP,
                                        calendar.getTimeInMillis() - 1000 * mSelectedNotification,
                                        AlarmManager.INTERVAL_DAY * 7,
                                        pendingIntent);
                            }
                        } else {
                            alarmManager.set(AlarmManager.RTC_WAKEUP,
                                    calendar.getTimeInMillis() - 1000 * mSelectedNotification,
                                    pendingIntent);
                        }
                        intentArray.add(pendingIntent);
                    }

                    mTaskTitleText.setText("");
                    initializeDate();
                    mStartDateEditText.setText(mStartTimeDay + "/" + (mStartTimeMonth + 1) + "/" + mStartTimeYear);
                    mEndDateEditText.setText(mEndTimeDay + "/" + (mEndTimeMonth + 1) + "/" + mEndTimeYear);
                    showCorrectTime(mStartTimeHour, mStartTimeMinute, "start");
                    showCorrectTime(mEndTimeHour, mEndTimeMinute,"end");
                    mNotifyCheckBox.setChecked(false);
                    mRepeatNotificationCheckbox.setChecked(false);
                    mRequiredTextView.setText("");
                }
            }
        });
    }

    private void taskAddedText() {
        Toast.makeText(this, R.string.task_added_toast, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onBackPressed() {
        if (mDrawerLayout.isDrawerOpen(GravityCompat.START)) {
            mDrawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        switch (menuItem.getItemId()) {
            case R.id.nav_home:
                Intent homeIntent = new Intent(TaskActivity.this, MainActivity.class);
                startActivity(homeIntent);
                break;
            case R.id.nav_tasks:
                break;
            case R.id.nav_folders:
                Intent foldersIntent = new Intent(TaskActivity.this, FolderActivity.class);
                startActivity(foldersIntent);
                break;
            case R.id.nav_lists:
                Intent listsIntent = new Intent(TaskActivity.this, ListActivity.class );
                startActivity(listsIntent);
                break;
            case R.id.nav_quotes:
                Intent quotesIntent = new Intent(TaskActivity.this, QuoteActivity.class );
                startActivity(quotesIntent);
                break;
            case R.id.nav_goals:
                Intent goalsIntent = new Intent(TaskActivity.this, GoalActivity.class);
                startActivity(goalsIntent);
                break;
        }
        mDrawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }

    private Integer checkNotifyValue(String notificationValue) {
        if (notificationValue.equals(mOccurrence)){
            mNotificationMinutesString = " starting now";
            return 0;
        } else if (notificationValue.equals(mTenMin)){
            mNotificationMinutesString = " starting after 10 min";
            return 60*10;
        } else if (notificationValue.equals(mOneHour)){
            mNotificationMinutesString = " starting after 1 hour";
            return 60*60;
        } else {
            mNotificationMinutesString = " starting tomorrow ";
            return 60*60*24;
        }
    }

    private void initializeDate() {
        mYearToday = mCurrCalendar.get(Calendar.YEAR);
        mMonthToday = mCurrCalendar.get(Calendar.MONTH);
        mDayToday = mCurrCalendar.get(Calendar.DAY_OF_MONTH);
        mHourToday = mCurrCalendar.get(Calendar.HOUR_OF_DAY);
        mMinuteToday = mCurrCalendar.get(Calendar.MINUTE);

        mStartTimeYear = mYearToday;
        mStartTimeMonth = mMonthToday;
        mStartTimeDay = mDayToday;
        mStartTimeHour = mHourToday;
        mStartTimeMinute = mMinuteToday;

        mEndTimeYear = mYearToday;
        mEndTimeMonth = mMonthToday;
        mEndTimeDay = mDayToday;
        mEndTimeHour = mHourToday;
        mEndTimeMinute = mMinuteToday;
    }

    private void showCorrectTime(int hour, int minute, String chosenField) {
        if (chosenField.equals("start")) {
            if (minute < 10) {
                mStartTimeEditText.setText(hour + ":" + "0" + minute);
            } else {
                mStartTimeEditText.setText(hour + ":" + minute);
            }
        } else {
            if (minute < 10) {
                mEndTimeEditText.setText(hour + ":" + "0" + minute);
            } else{
                mEndTimeEditText.setText(hour + ":" + minute);
            }
        }
    }
}