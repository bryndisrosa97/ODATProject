package is.hi.hbv601g.odat.activities;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.room.Room;

import com.google.android.material.navigation.NavigationView;

import is.hi.hbv601g.odat.ODATDatabase;
import is.hi.hbv601g.odat.R;
import is.hi.hbv601g.odat.entities.Goal;

public class GoalActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    private static ODATDatabase mODATDatabase;
    private EditText mGoalText;
    private Button mAddGoalButton;
    private DrawerLayout mDrawerLayout;
    private NavigationView mNavigationView;
    private Toolbar mToolbar;
    private TextView mFailedTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_goal);
        mDrawerLayout = findViewById(R.id.drawerLayout);
        mNavigationView = findViewById(R.id.nav_view);
        mToolbar = findViewById(R.id.toolbar);

        setSupportActionBar(mToolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        mNavigationView.bringToFront();

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, mDrawerLayout, mToolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        mDrawerLayout.addDrawerListener(toggle);
        toggle.syncState();
        mNavigationView.setNavigationItemSelectedListener(this);
        mNavigationView.setCheckedItem(R.id.nav_goals);

        mODATDatabase = Room.databaseBuilder(getApplicationContext(), ODATDatabase.class, "ODAT").allowMainThreadQueries().build();

        mAddGoalButton = (Button) findViewById(R.id.add_goal_button);
        mGoalText = (EditText) findViewById(R.id.goal_txt);
        mFailedTextView = (TextView) findViewById(R.id.add_failed_textView);

        mAddGoalButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String goalDescription = mGoalText.getText().toString();

                if (TextUtils.isEmpty(goalDescription)) {
                    mFailedTextView.setText("Description of goal is required");
                } else {
                    Goal goal = new Goal();
                    goal.setDescription(goalDescription);

                    mODATDatabase.mGoalDao().addGoal(goal);
                    goalAddedText();

                    mGoalText.setText("");

                    mFailedTextView.setText("");
                }
            }
        });
    }

    private void goalAddedText() {
        Toast.makeText(this, R.string.goal_added_toast, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onBackPressed() {
        if (mDrawerLayout.isDrawerOpen(GravityCompat.START)) {
            mDrawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        switch (menuItem.getItemId()) {
            case R.id.nav_home:
                Intent homeIntent = new Intent(GoalActivity.this, MainActivity.class);
                startActivity(homeIntent);
                break;
            case R.id.nav_tasks:
                Intent tasksIntent = new Intent(GoalActivity.this, TaskActivity.class);
                startActivity(tasksIntent);
                break;
            case R.id.nav_folders:
                Intent foldersIntent = new Intent(GoalActivity.this, FolderActivity.class);
                startActivity(foldersIntent);
                break;
            case R.id.nav_lists:
                Intent listsIntent = new Intent(GoalActivity.this, ListActivity.class );
                startActivity(listsIntent);
                break;
            case R.id.nav_quotes:
                Intent quoteIntent = new Intent(GoalActivity.this, QuoteActivity.class );
                startActivity(quoteIntent);
                break;
            case R.id.nav_goals:
                break;
        }
        mDrawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }

}