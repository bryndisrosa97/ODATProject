package is.hi.hbv601g.odat.activities;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.room.Room;

import com.google.android.material.navigation.NavigationView;

import is.hi.hbv601g.odat.ODATDatabase;
import is.hi.hbv601g.odat.R;
import is.hi.hbv601g.odat.entities.TList;

public class AddListActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    private int[] mInsets = new int[4];

    private static ODATDatabase mODATDatabase;
    private static EditText mListName;
    private Button mAddListButton;
    private DrawerLayout mDrawerLayout;
    private NavigationView mNavigationView;
    private LinearLayout linearLayout;
    private Toolbar mToolbar;
    private ScrollView scroll;


    public final int[] getInsets() {
        return mInsets;
    }


    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_list);
        mDrawerLayout = findViewById(R.id.drawerLayout);
        mNavigationView = findViewById(R.id.nav_view);
        mToolbar = findViewById(R.id.toolbar);

        setSupportActionBar(mToolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        mNavigationView.bringToFront();

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, mDrawerLayout, mToolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        mDrawerLayout.addDrawerListener(toggle);
        toggle.syncState();
        mNavigationView.setNavigationItemSelectedListener(this);
        mNavigationView.setCheckedItem(R.id.nav_lists);

        mODATDatabase = Room.databaseBuilder(getApplicationContext(), ODATDatabase.class, "ODAT").allowMainThreadQueries().build();
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);

        mAddListButton = (Button) findViewById(R.id.bn_savelist);
        mAddListButton.setBackgroundColor(getResources().getColor(R.color.HotPink));
        mListName = (EditText) findViewById(R.id.txt_listname);



        mAddListButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String mTListName = mListName.getText().toString();
                mAddListButton.setBackgroundColor(getResources().getColor(R.color.HotPink));
                if (!mTListName.isEmpty()) {
                    TList tlist = new TList();
                    tlist.setListName(mTListName);
                    mODATDatabase.mTListDao().addTList(tlist);
                    mListName.setText("");
                    listAddedText();
                    Intent listActivityIntent = new Intent(AddListActivity.this, ListActivity.class);
                    startActivity(listActivityIntent);
                } else {
                    Toast.makeText(AddListActivity.this, "Not empty string!", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void listAddedText() {
        Toast.makeText(this, R.string.list_added_toast, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onBackPressed() {
        if (mDrawerLayout.isDrawerOpen(GravityCompat.START)) {
            mDrawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }


    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.nav_home:
                Intent homeIntent = new Intent(AddListActivity.this, MainActivity.class);
                startActivity(homeIntent);
                break;
            case R.id.nav_tasks:
                Intent tasksIntent = new Intent(AddListActivity.this, TaskActivity.class);
                startActivity(tasksIntent);
                break;
            case R.id.nav_folders:
                Intent foldersIntent = new Intent(AddListActivity.this, FolderActivity.class);
                startActivity(foldersIntent);
                break;
            case R.id.nav_lists:
                break;
            case R.id.nav_quotes:
                Intent quotesIntent = new Intent(AddListActivity.this, QuoteActivity.class);
                startActivity(quotesIntent);
                break;
            case R.id.nav_goals:
                Intent goalsIntent = new Intent(AddListActivity.this, GoalActivity.class);
                startActivity(goalsIntent);
                break;
        }
        mDrawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }


}
