package is.hi.hbv601g.odat.activities;

import android.content.Intent;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.room.Room;

import com.google.android.material.navigation.NavigationView;

import java.util.List;

import is.hi.hbv601g.odat.ODATDatabase;
import is.hi.hbv601g.odat.R;
import is.hi.hbv601g.odat.entities.TList;

public class ListActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    private Button mAddNewListButton;
    private static ODATDatabase mODATDatabase;
    private TextView mDisplayListNames;
    private List<TList> mTLists;
    private int mButtonListId;
    private Button mListButton;
    private Button mSelectedListButton;
    private Button mDeleteListButton;
    private DrawerLayout mDrawerLayout;
    private NavigationView mNavigationView;
    private Toolbar mToolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);
        mDrawerLayout = findViewById(R.id.drawerLayout);
        mNavigationView = findViewById(R.id.nav_view);
        mToolbar = findViewById(R.id.toolbar);

        setSupportActionBar(mToolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        mNavigationView.bringToFront();

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, mDrawerLayout, mToolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        mDrawerLayout.addDrawerListener(toggle);
        toggle.syncState();
        mNavigationView.setNavigationItemSelectedListener(this);
        mNavigationView.setCheckedItem(R.id.nav_lists);


        mODATDatabase = Room.databaseBuilder(getApplicationContext(), ODATDatabase.class, "ODAT").allowMainThreadQueries().build();

        //mDisplayListNames = (TextView) findViewById(R.id.txt_displaylists);

        mTLists = mODATDatabase.mTListDao().getAllTLists();
        LinearLayout linearLayoutContainer = (LinearLayout) findViewById(R.id.list_activity);

        mButtonListId = 0;
        for (TList tList : mTLists) {
            LinearLayout linearLayout = new LinearLayout(this);
            linearLayoutContainer.addView(linearLayout);
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);

            mListButton = new Button(this);
            mDeleteListButton = new Button(this);

            DisplayMetrics dm = new DisplayMetrics();
            this.getWindowManager().getDefaultDisplay().getMetrics(dm);
            int width = dm.widthPixels;
            mListButton.setWidth(width*7/8);
            mDeleteListButton.setWidth(width*1/8);

            String tListName = tList.getListName();
            mListButton.setId(mButtonListId);
            int id = mListButton.getId();
            int tListId = tList.getId();
            mListButton.setText(tListName);

            linearLayout.addView(mListButton, layoutParams);
            mSelectedListButton = (Button) findViewById(id);
            mDeleteListButton.setBackground(getDrawable(R.drawable.delete));
            linearLayout.addView(mDeleteListButton, layoutParams);
            mSelectedListButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent mEditListIntent = new Intent(ListActivity.this, EditListActivity.class);
                    mEditListIntent.putExtra("mSelectedListId", String.valueOf(tListId));
                    startActivity(mEditListIntent);
                }
            });
            mDeleteListButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mODATDatabase.mTListDao().deleteTList(tList);
                    Intent tListIntent = getIntent();
                    finish();
                    startActivity(tListIntent);
                }
            });
            mButtonListId++;
        }

        mAddNewListButton = (Button) findViewById(R.id.bn_addnewlist);
        mAddNewListButton.setBackgroundColor(getResources().getColor(R.color.HotPink));

        mAddNewListButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent newListIntent = new Intent(ListActivity.this, AddListActivity.class);
                startActivity(newListIntent);
            }
        });
    }

    @Override
    public void onBackPressed() {
        if (mDrawerLayout.isDrawerOpen(GravityCompat.START)) {
            mDrawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        switch (menuItem.getItemId()) {
            case R.id.nav_home:
                Intent homeIntent = new Intent(ListActivity.this, MainActivity.class);
                startActivity(homeIntent);
                break;
            case R.id.nav_tasks:
                Intent tasksIntent = new Intent(ListActivity.this, TaskActivity.class);
                startActivity(tasksIntent);
                break;
            case R.id.nav_folders:
                Intent foldersIntent = new Intent(ListActivity.this, FolderActivity.class);
                startActivity(foldersIntent);
                break;
            case R.id.nav_lists:
                break;
            case R.id.nav_quotes:
                Intent quotesIntent = new Intent(ListActivity.this, QuoteActivity.class);
                startActivity(quotesIntent);
                break;
            case R.id.nav_goals:
                Intent goalsIntent = new Intent(ListActivity.this, GoalActivity.class);
                startActivity(goalsIntent);
                break;
        }
        mDrawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }
}