package is.hi.hbv601g.odat.activities;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;

import java.util.ArrayList;

import is.hi.hbv601g.odat.R;

public class EventListAdapter extends ArrayAdapter {

    private final Activity mContext;
    private  ArrayList<String> mNameOfTask;
    private  ArrayList<String> mTimeOfTask;
    private  ArrayList<String> mFolderNameOfTask;

    public EventListAdapter(Activity context, ArrayList<String> nameOfTask, ArrayList<String> timeOfTask,  ArrayList<String> folderNameOfTask) {
        super(context, R.layout.eventlist, nameOfTask);
        this.mContext = context;
        this.mNameOfTask = nameOfTask;
        this.mTimeOfTask = timeOfTask;
        this.mFolderNameOfTask = folderNameOfTask;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @NonNull
    @Override
    public View getView(int position, View view, ViewGroup parent) {
        LayoutInflater inflater= mContext.getLayoutInflater();
        View rowView = inflater.inflate(R.layout.eventlist, null, false);

        TextView timer = (TextView) rowView.findViewById(R.id.timeer);
        TextView titleText = (TextView) rowView.findViewById(R.id.title);
        TextView subtitleText = (TextView) rowView.findViewById(R.id.subtitle);

        String timeOfTask = mTimeOfTask.get(position);
        String nameOfTask =  mNameOfTask.get(position);
        String folderNameOfTask =  mFolderNameOfTask.get(position);

        timer.setText(timeOfTask);
        titleText.setText(nameOfTask);
        subtitleText.setText(folderNameOfTask);

        return rowView;
    };
}
