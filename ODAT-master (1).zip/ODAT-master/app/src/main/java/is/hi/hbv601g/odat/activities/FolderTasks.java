package is.hi.hbv601g.odat.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.room.Room;

import com.google.android.material.navigation.NavigationView;

import java.util.ArrayList;
import java.util.List;

import is.hi.hbv601g.odat.ODATDatabase;
import is.hi.hbv601g.odat.R;
import is.hi.hbv601g.odat.entities.Task;

public class FolderTasks extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    private DrawerLayout mDrawerLayout;
    private NavigationView mNavigationView;
    private Toolbar mToolbar;
    private static ODATDatabase mODATDatabase;
    private TextView mFolderNameTextView;
    private List<Task> mFolderTasks;
    private ListView mListView;

    private ArrayList<String> mTaskNameOfDay = new ArrayList<String>();
    private ArrayList<String> mTaskTimeOfDay = new ArrayList<String>();
    private ArrayList<Task> mTask = new ArrayList<Task>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_folder_tasks);
        mDrawerLayout = findViewById(R.id.drawerLayout);
        mNavigationView = findViewById(R.id.nav_view);
        mToolbar = findViewById(R.id.toolbar);

        setSupportActionBar(mToolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        mNavigationView.bringToFront();

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, mDrawerLayout, mToolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        mDrawerLayout.addDrawerListener(toggle);
        toggle.syncState();
        mNavigationView.setNavigationItemSelectedListener(this);
        mNavigationView.setCheckedItem(R.id.nav_folders);

        mODATDatabase = Room.databaseBuilder(getApplicationContext(), ODATDatabase.class, "ODAT").allowMainThreadQueries().build();

        Bundle bundle = getIntent().getExtras();
        String mSelectedFolder = bundle.getString("mSelectedFolder");

        mFolderNameTextView = (TextView) findViewById(R.id.folder_name);
        mFolderNameTextView.setText(mSelectedFolder);

        mFolderTasks = mODATDatabase.mTaskDao().getTasksByFolderName(mSelectedFolder);

        mListView = findViewById(R.id.list);

        for (Task task : mFolderTasks) {
            String taskTitle = task.getTitle();
            String taskStartTime = task.getStartTime();
            String taskEndTime = task.getEndTime();
            String time = taskStartTime + " - " + " " + " " + taskEndTime;
            mTaskNameOfDay.add(taskTitle);
            mTaskTimeOfDay.add(time);
            mTask.add(task);
        }

        FolderTasksListAdapter adapter = new FolderTasksListAdapter(this, mTaskNameOfDay, mTaskTimeOfDay, mTask);
        mListView.setAdapter(adapter);
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        switch (menuItem.getItemId()) {
            case R.id.nav_home:
                Intent homeIntent = new Intent(FolderTasks.this, MainActivity.class);
                startActivity(homeIntent);
                break;
            case R.id.nav_tasks:
                Intent tasksIntent = new Intent(FolderTasks.this, TaskActivity.class);
                startActivity(tasksIntent);
                break;
            case R.id.nav_folders:
                Intent FoldersIntent = new Intent(FolderTasks.this, FolderActivity.class );
                startActivity(FoldersIntent);
                break;
            case R.id.nav_lists:
                Intent listsIntent = new Intent(FolderTasks.this, ListActivity.class );
                startActivity(listsIntent);
                break;
            case R.id.nav_quotes:
                Intent quotesIntent = new Intent(FolderTasks.this, QuoteActivity.class);
                startActivity(quotesIntent);
                break;
            case R.id.nav_goals:
                Intent goalsIntent = new Intent(FolderTasks.this, GoalActivity.class);
                startActivity(goalsIntent);
                break;
        }
        mDrawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }
}