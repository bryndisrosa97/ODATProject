package is.hi.hbv601g.odat.activities;

import android.content.Intent;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.room.Room;

import com.google.android.material.navigation.NavigationView;

import java.util.List;

import is.hi.hbv601g.odat.ODATDatabase;
import is.hi.hbv601g.odat.R;
import is.hi.hbv601g.odat.entities.TList;
import is.hi.hbv601g.odat.entities.TListItem;

public class EditListActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    private static ODATDatabase mODATDatabase;
    private TextView mListNameTextView;
    private EditText mListItemEditText;
    private List<TListItem> mTListItems;
    private CheckBox mTextCheckbox;
    private CheckBox mSelectedCheckbox;
    private Button mAddListItemButton;
    private Button mDeleteListItemButton;
    private DrawerLayout mDrawerLayout;
    private NavigationView mNavigationView;
    private Toolbar mToolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_list);
        mDrawerLayout = findViewById(R.id.drawerLayout);
        mNavigationView = findViewById(R.id.nav_view);
        mToolbar = findViewById(R.id.toolbar);

        setSupportActionBar(mToolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        mNavigationView.bringToFront();

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, mDrawerLayout, mToolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        mDrawerLayout.addDrawerListener(toggle);
        toggle.syncState();
        mNavigationView.setNavigationItemSelectedListener(this);
        mNavigationView.setCheckedItem(R.id.nav_lists);

        mODATDatabase = Room.databaseBuilder(getApplicationContext(), ODATDatabase.class, "ODAT").allowMainThreadQueries().build();

        Bundle mBundle = getIntent().getExtras();
        String mSelectedListIdString = mBundle.getString("mSelectedListId");
        int mSelectedListId = Integer.parseInt(mSelectedListIdString);

        mListNameTextView = (TextView) findViewById(R.id.txt_tlistname);
        mListItemEditText = (EditText) findViewById(R.id.txt_listitem);
        mAddListItemButton = (Button) findViewById(R.id.bn_add_listitem);
        mAddListItemButton.setBackgroundColor(getResources().getColor(R.color.HotPink));


        TList mSelectedTList = mODATDatabase.mTListDao().getListById(mSelectedListId);
        String mSelectedTListName = mSelectedTList.getListName();

        mListNameTextView.setText(mSelectedTListName);

        mTListItems = mODATDatabase.tListitemDao().getTlistitemByListId(mSelectedListId);

        LinearLayout linearLayoutContainer = (LinearLayout) findViewById(R.id.listitem_layout);

        for (TListItem tListItem : mTListItems) {
            LinearLayout linearLayout = new LinearLayout(this);
            linearLayoutContainer.addView(linearLayout);
            LayoutParams layoutParams = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);

            mTextCheckbox = new CheckBox(this);
            mDeleteListItemButton = new Button(this);

            DisplayMetrics dm = new DisplayMetrics();
            this.getWindowManager().getDefaultDisplay().getMetrics(dm);
            int width = dm.widthPixels;
            mTextCheckbox.setWidth(width*7/8);
            mDeleteListItemButton.setWidth(width*1/8);
            mDeleteListItemButton.setBackground(getDrawable(R.drawable.delete));

            int tListItemId = tListItem.getId();
            Boolean checked = mODATDatabase.tListitemDao().isChecked(tListItemId);
            String mTListItemName = tListItem.getListItemName();
            mTextCheckbox.setId(tListItemId);
            mTextCheckbox.setText(mTListItemName);

            linearLayout.addView(mTextCheckbox, layoutParams);
            linearLayout.addView(mDeleteListItemButton, layoutParams);
            mSelectedCheckbox = (CheckBox) findViewById(tListItemId);
            mSelectedCheckbox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    if (isChecked) {
                        int id = buttonView.getId();
                        tListItem.setChecked(true);
                        mODATDatabase.tListitemDao().updateChecked(true, tListItemId);
                    } else {
                        tListItem.setChecked(false);
                        mODATDatabase.tListitemDao().updateChecked(false, tListItemId);
                    }
                }
            });
            mDeleteListItemButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mODATDatabase.tListitemDao().deleteTlistitem(tListItem);
                    Intent mTListItemIntent = getIntent();
                    finish();
                    startActivity(mTListItemIntent);
                }
            });
            mSelectedCheckbox.setChecked(checked);

        }
        mAddListItemButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TListItem tListItem = new TListItem();
                String mListItemName = mListItemEditText.getText().toString();
                if (mListItemName.isEmpty()) {
                    Toast.makeText(EditListActivity.this, "Not empty string!", Toast.LENGTH_SHORT).show();
                } else {
                    tListItem.setListItemName(mListItemName);
                    tListItem.setChecked(false);
                    int listId = mSelectedTList.getId();
                    tListItem.setListId(listId);
                    mODATDatabase.tListitemDao().addTlistitem(tListItem);
                    LinearLayout linearLayout = (LinearLayout) findViewById(R.id.listitem_layout);
                    LayoutParams layoutParams = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
                    mTextCheckbox = new CheckBox(EditListActivity.this);
                    mTextCheckbox.setText(mListItemName);
                    mTextCheckbox.setId(listId);
                    linearLayout.addView(mTextCheckbox, layoutParams);
                    Intent mTListItemIntent = getIntent();
                    finish();
                    startActivity(mTListItemIntent);
                }
            }
        });
        mListItemEditText.setText("");
    }

    @Override
    public void onBackPressed() {
        if (mDrawerLayout.isDrawerOpen(GravityCompat.START)) {
            mDrawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.nav_home:
                Intent homeIntent = new Intent(EditListActivity.this, MainActivity.class);
                startActivity(homeIntent);
                break;
            case R.id.nav_tasks:
                Intent tasksIntent = new Intent(EditListActivity.this, TaskActivity.class);
                startActivity(tasksIntent);
                break;
            case R.id.nav_folders:
                Intent foldersIntent = new Intent(EditListActivity.this, FolderActivity.class);
                startActivity(foldersIntent);
                break;
            case R.id.nav_lists:
                break;
            case R.id.nav_quotes:
                Intent quotesIntent = new Intent(EditListActivity.this, QuoteActivity.class);
                startActivity(quotesIntent);
                break;
            case R.id.nav_goals:
                Intent goalsIntent = new Intent(EditListActivity.this, GoalActivity.class);
                startActivity(goalsIntent);
                break;
        }
        mDrawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }
}