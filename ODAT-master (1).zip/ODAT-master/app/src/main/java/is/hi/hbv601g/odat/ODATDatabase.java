package is.hi.hbv601g.odat;

import androidx.room.Database;
import androidx.room.RoomDatabase;

import is.hi.hbv601g.odat.daos.GoalDao;
import is.hi.hbv601g.odat.daos.TFolderDao;
import is.hi.hbv601g.odat.daos.TListDao;
import is.hi.hbv601g.odat.daos.TaskDao;
import is.hi.hbv601g.odat.daos.TlistitemDao;
import is.hi.hbv601g.odat.entities.Goal;
import is.hi.hbv601g.odat.entities.TFolder;
import is.hi.hbv601g.odat.entities.Task;
import is.hi.hbv601g.odat.entities.TList;
import is.hi.hbv601g.odat.entities.TListItem;

@Database(entities = {Goal.class, TFolder.class, Task.class, TList.class, TListItem.class}, version = 3)
public abstract class ODATDatabase extends RoomDatabase {
    public abstract GoalDao mGoalDao();
    public abstract TFolderDao mTFolderDao();
    public abstract TaskDao mTaskDao();

    public abstract TListDao mTListDao();
    public abstract TlistitemDao tListitemDao();
}