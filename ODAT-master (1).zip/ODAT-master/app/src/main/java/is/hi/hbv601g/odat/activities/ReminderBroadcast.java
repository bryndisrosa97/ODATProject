package is.hi.hbv601g.odat.activities;

import android.app.Notification;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import is.hi.hbv601g.odat.R;

public class ReminderBroadcast extends BroadcastReceiver {
    private static int id = 0;

    @Override
    public void onReceive(Context context, Intent intent){
        String message = intent.getStringExtra("toastMessage");

        Notification notification = new NotificationCompat.Builder(context, "taskNotification")
                .setSmallIcon(R.drawable.ic_baseline_check_box_pink)
                .setContentTitle("ODAT")
                .setContentText(message)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setColor(Color.MAGENTA)
                .setContentIntent(TaskActivity.mContentIntent)
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .build();

        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(context);

        notificationManager.notify( id, notification);
    }

    public static void setId(int id) {
        ReminderBroadcast.id = id;
    }
}
