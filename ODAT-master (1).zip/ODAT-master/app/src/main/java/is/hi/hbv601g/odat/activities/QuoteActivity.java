package is.hi.hbv601g.odat.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.navigation.NavigationView;

import java.util.Arrays;
import java.util.Collections;

import is.hi.hbv601g.odat.R;
import is.hi.hbv601g.odat.entities.Quotes;

public class QuoteActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    DrawerLayout mDrawerLayout;
    NavigationView mNavigationView;
    Toolbar mToolbar;
    private ImageView mImageView;
    private TextView mTextView;
    private Button mButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quoete);

        mDrawerLayout = findViewById(R.id.drawerLayout);
        mNavigationView = findViewById(R.id.nav_view);
        mToolbar = findViewById(R.id.toolbar);
        mImageView = (ImageView)findViewById(R.id.imageView);
        mTextView = (TextView)findViewById(R.id.quote);
        mButton = (Button) findViewById(R.id.quote_button);

        setSupportActionBar(mToolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        mNavigationView.bringToFront();

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, mDrawerLayout, mToolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        mDrawerLayout.addDrawerListener(toggle);
        toggle.syncState();
        mNavigationView.setNavigationItemSelectedListener(this);
        mNavigationView.setCheckedItem(R.id.nav_quotes);

        showRandomQuotes();

        mButton.setBackgroundColor(getResources().getColor(R.color.HotPink));

        mButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showRandomQuotes();
                mButton.setBackgroundColor(getResources().getColor(R.color.HotPink));
            }
        });
    }

    @Override
    public void onBackPressed() {
        if (mDrawerLayout.isDrawerOpen(GravityCompat.START)) {
            mDrawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        switch (menuItem.getItemId()) {
            case R.id.nav_home:
                Intent homeIntent = new Intent(QuoteActivity.this, MainActivity.class);
                startActivity(homeIntent);
                break;
            case R.id.nav_tasks:
                Intent tasksIntent = new Intent(QuoteActivity.this, TaskActivity.class);
                startActivity(tasksIntent);
                break;
            case R.id.nav_folders:
                Intent foldersIntent = new Intent(QuoteActivity.this, FolderActivity.class);
                startActivity(foldersIntent);
                break;
            case R.id.nav_lists:
                Intent listsIntent = new Intent(QuoteActivity.this, ListActivity.class );
                startActivity(listsIntent);
                break;
            case R.id.nav_quotes:
                break;
            case R.id.nav_goals:
                Intent goalsIntent = new Intent(QuoteActivity.this, GoalActivity.class);
                startActivity(goalsIntent);
                break;
        }
        mDrawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }

    public void showRandomQuotes() {
        shuffleQuotes();
        mImageView.setImageResource(quoteArray[0].getmImage());
        mTextView.setText(quoteArray[0].getmQuotes());
    }

    Quotes f01 = new Quotes(R.drawable.nemo,  "If you can dream it, you can do it. - Walt Disney, 'Just keep swimming! - Finding Nemo ");
    Quotes f02 = new Quotes(R.drawable.star,  "\"The flower that blooms in adversity is the most rare and beautiful of all.\" - Mulan");
    Quotes f03 = new Quotes(R.drawable.cutedog,  " \"The average dog is a nicer person than the average person.\" - Unknown");
    Quotes f04 = new Quotes(R.drawable.star,  "\"Að eignast vin tekur andartak... að vera vinur tekur alla ævi.\" - Unknown");
    Quotes f05 = new Quotes(R.drawable.star,  "\"Don’t spend time beating on a wall, hoping to transform it into a door.\" - Coco Chanel ");
    Quotes f06 = new Quotes(R.drawable.noi,  "No longer by my side but forever in my heart\n");
    Quotes f07 = new Quotes(R.drawable.star,  "\"Success is often achieved by those who do not know that failure is inevitable.\" - Coco Chanel ");
    Quotes f08 = new Quotes(R.drawable.star,  "\"You live but once; you might as well be amusing.\" - Coco Chanel");
    Quotes f09 = new Quotes(R.drawable.star,  " “WHY DO WE FALL? SO THAT WE CAN LEARN TO PICK OURSELVES BACK UP.\" - Batman");
    Quotes f10 = new Quotes(R.drawable.star,  "\"IF YOU’RE GOOD AT SOMETHING, NEVER DO IT FOR FREE.\" - The Joker ");
    Quotes f11 = new Quotes(R.drawable.star,  "\"In order to be irreplaceable, one must always be different.\" - Coco Chanel");
    Quotes f12 = new Quotes(R.drawable.harrypotter,  "\"It does not do well to dwell on dreams and forget to live.\" - Albus Dumbledore");
    Quotes f013 = new Quotes(R.drawable.harrypotter,  " \"Fear of a name only increases fear of the thing itself.\" - Hermione Granger");
    Quotes f14 = new Quotes(R.drawable.harrypotter,  " \"When in doubt, go to the library.\" - Ron Weasley");
    Quotes f15 = new Quotes(R.drawable.harrypotter,  "  \"It is our choices, Harry, that show what we truly are, far more than our abilities.\" - Albus Dumbledore");
    Quotes f16 = new Quotes(R.drawable.harrypotter,  "\"\"Honestly, if you were any slower, you’d be going backward.\" - Draco Malfoy");
    Quotes f17 = new Quotes(R.drawable.hogwarts,  "\"I solemnly swear I am up to no good.\" - Harry Potter");
    Quotes f18 = new Quotes(R.drawable.hogwarts,  "\"Don’t let the muggles get you down.\" - Ron Weasle");
    Quotes f19 = new Quotes(R.drawable.hogwarts,  " \"If you want to know what a man’s like, take a good look at how he treats his inferiors, not his equals.\" - Sirius Black ");
    Quotes f20 = new Quotes(R.drawable.hogwarts,  "\"We are only as strong as we are united, as weak as we are divided.\" - Albus Dumbledore");
    Quotes f21 = new Quotes(R.drawable.hogwarts,  " \"Curiosity is not a sin… but we should exercise caution with our curiosity… yes, indeed.\" - Albus Dumbledore");
    Quotes f22 = new Quotes(R.drawable.harry,  "\"Differences of habit and language are nothing at all if our aims are identical and our hearts are open.\" - Albus Dumbledore ");
    Quotes f23 = new Quotes(R.drawable.harry,  "' I think I will just go down and have some pudding and wait for it all to turn up — it always does in the end.\" - Luna Lovegood ");
    Quotes f24 = new Quotes(R.drawable.harry,  "\"We’ve all got both light and dark inside us. What matters is the part we choose to act on. That’s who we really are.\" - Sirius Black");
    Quotes f25 = new Quotes(R.drawable.harry,  "\"Youth can not know how age thinks and feels. But old men are guilty if they forget what it was to be young.\" - Albus Dumbledore");
    Quotes f26 = new Quotes(R.drawable.harry,  "\"Things we lose have a way of coming back to us in the end, if not always in the way we expect.\" - Luna Lovegood.");
    Quotes f27 = new Quotes(R.drawable.harry,  " \"Wit beyond measure is man’s greatest treasure.\" - Luna Lovegood");
    Quotes f28 = new Quotes(R.drawable.star,  "\"Age is foolish and forgetful when it underestimates youth.\" - Albus Dumbledore");
    Quotes f29 = new Quotes(R.drawable.star,  "\"It is the quality of one’s convictions that determines success, not the number of followers.\" - Remus Lupin");
    Quotes f30 = new Quotes(R.drawable.snakealways,  "\"After all this time? Always, said Snape.\"");
    Quotes f31 = new Quotes(R.drawable.always,  "\"Happiness can be found, even in the darkest of times, if one only remembers to turn on the light.\" - Albus Dumbledore");
    Quotes f32 = new Quotes(R.drawable.always,  "\"Words are, in my not-so-humble opinion, our most inexhaustible source of magic. Capable of both inflicting injury, and remedying it.\" - Albus Dumbledore");
    Quotes f33 = new Quotes(R.drawable.always,  " \"The best of us sometimes eat our words.\" - Albus Dubmledore");
    Quotes f34 = new Quotes(R.drawable.always,  "\"You think the dead we loved ever truly leave us? You think that we don’t recall them more clearly than ever in times of great trouble?\" - Albus Dumbledore");
    Quotes f35 = new Quotes(R.drawable.always,  "\"Anything’s possible if you’ve got enough nerve.\" - Ginny Weasley");
    Quotes f36 = new Quotes(R.drawable.winniethepooth,  "\"You’re braver than you believe, stronger than you seem, and smarter than you think.\" - Winnie the Pooh");
    Quotes f37 = new Quotes(R.drawable.herkules,  "\"A true hero isn’t measured by the size of his strength, but by the strength of his heart.\" - Hercules ");
    Quotes f38 = new Quotes(R.drawable.rotta,  "\"If you focus on what you left behind, you will never see what lies ahead.\" - Ratatouille");
    Quotes f39 = new Quotes(R.drawable.star,  " \"Open different doors. You may find a you there that you never knew was yours. Anything can happen.\" - Mary Poppins");
    Quotes f40 = new Quotes(R.drawable.lionking,  " \"Look inside yourself. You are more than what you have become.\" - The Lion King");
    Quotes f41 = new Quotes(R.drawable.dumbo,  "\"The very things that hold you down are going to lift you up.\" - Dumbo");
    Quotes f42 = new Quotes(R.drawable.star,  "\"You control your destiny. You don’t need magic to do it. And there are no magical shortcuts to solving your problems.\" - Brave");
    Quotes f43 = new Quotes(R.drawable.jsparrow,  "\"The problem is not the problem. The problem is your attitude about the problem.\" - Pirates of the Caribbean ");
    Quotes f44 = new Quotes(R.drawable.lionking,  "\"Oh, yes, the past can hurt. But the way I see it, you can either run from it, or learn from it.\" - The Lion King");
    Quotes f45 = new Quotes(R.drawable.smiling,  " \"Remember, you’re the one who can fill the world with sunshine.\" - Snow White and the Seven Dwarves ");
    Quotes f46 = new Quotes(R.drawable.disneypink,  " \"All our dreams can come true, if we have the courage to pursue them.\" - Walt Disney");
    Quotes f47 = new Quotes(R.drawable.disneypink,  "\"The way to get started is to quit talking and begin doing.\" - Walt Disney', ' \"Get a good idea and stay with it. Do it, and work at it until it’s done right.\" - Walt Disney");
    Quotes f48 = new Quotes(R.drawable.disneypink,  "\"First, think. Second, believe. Third, dream. And finally, dare.\" – Walt Disney");
    Quotes f49 = new Quotes(R.drawable.rotta,  "\"You must not let anyone define your limits because of where you come from. Your only limit is your soul.\" – Ratatouille");
    Quotes f50 = new Quotes(R.drawable.disneypink,  "\"We keep moving forward, opening new doors, and doing new things, because we’re curious and curiosity keeps leading us down new paths.\" - Walt Disney");
    Quotes f51 = new Quotes(R.drawable.pinkvoffi,  "“Dogs are not our whole life, but they make our lives whole.”");
    Quotes f52 = new Quotes(R.drawable.pinkvoffi,  "“Keep calm and pet a dog.” – Unknown\n");
    Quotes f53 = new Quotes(R.drawable.cutedog,  "“Love is a four-legged word.” – Unknown");
    Quotes f54 = new Quotes(R.drawable.hsukypink,  "“It’s impossible to keep a straight face in the presence of one or more puppies.” – Unknown");
    Quotes f56 = new Quotes(R.drawable.noi2,  "“Dogs do speak, but only to those who know how to listen.”– Orhan Pamuk");

    Quotes [] quoteArray = new Quotes[] {
            f01, f02, f03, f04, f05, f06, f07, f08, f09, f10, f11,
            f12, f013, f14, f15, f16, f17, f18, f19, f20, f21, f22,
            f23, f24, f25, f26, f27, f28, f29, f30, f31, f32, f33,
            f34, f35, f36, f37, f38, f39, f40, f41, f42, f43, f44,
            f45, f46, f47, f48, f49, f50, f51, f52, f53, f54, f56
    };

    public void shuffleQuotes() {
        Collections.shuffle(Arrays.asList(quoteArray));
    }


}