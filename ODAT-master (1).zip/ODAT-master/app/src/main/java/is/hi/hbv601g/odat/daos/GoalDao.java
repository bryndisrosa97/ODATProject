package is.hi.hbv601g.odat.daos;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

import is.hi.hbv601g.odat.entities.Goal;

@Dao
public interface GoalDao {

    @Insert
    public void addGoal(Goal goal);

    @Delete
    public void deleteGoal(Goal goal);

    @Query("SELECT * FROM goals")
    public List<Goal> getAllGoals();

    /*
    @Query("SELECT * FROM goals " + "WHERE id IN (:goalIds)")
    public List<Goal> loadAllGoalsByIds(int[] goalIds);
    */
}
