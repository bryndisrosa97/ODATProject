package is.hi.hbv601g.odat.activities;

import android.app.Activity;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;

import androidx.room.Room;

import java.util.ArrayList;

import is.hi.hbv601g.odat.ODATDatabase;
import is.hi.hbv601g.odat.R;
import is.hi.hbv601g.odat.entities.Task;

public class FolderTasksListAdapter extends ArrayAdapter{

    private final Activity mContext;
    private ArrayList<String> mNameOfTask;
    private ArrayList<String> mTimeOfTask;
    private ArrayList<Task> mTask;
    private static ODATDatabase mODATDatabase;

    public FolderTasksListAdapter(Activity context, ArrayList<String> nameOfTask, ArrayList<String> timeOfTask, ArrayList<Task> task) {
        super(context, R.layout.folders_list, nameOfTask);
        this.mContext = context;
        this.mNameOfTask = nameOfTask;
        this.mTimeOfTask = timeOfTask;
        this.mTask = task;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View view, ViewGroup parent) {
        LayoutInflater inflater = mContext.getLayoutInflater();
        View rowView = inflater.inflate(R.layout.folders_list, null, false);

        mODATDatabase = Room.databaseBuilder(mContext.getApplicationContext(), ODATDatabase.class, "ODAT").allowMainThreadQueries().build();

        TextView mTimeTextView = (TextView) rowView.findViewById(R.id.timer);
        TextView mTitleTextView = (TextView) rowView.findViewById(R.id.title);
        Button mDeleteTaskButton = (Button) rowView.findViewById(R.id.delete_task_button);

        String mTimeText = mTimeOfTask.get(position);
        String mTitleText = mNameOfTask.get(position);
        Task mCurrentTask = mTask.get(position);

        mTimeTextView.setText(mTimeText);
        mTitleTextView.setText(mTitleText);
        mDeleteTaskButton.setBackground(mContext.getResources().getDrawable(R.drawable.delete));

        mDeleteTaskButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mODATDatabase.mTaskDao().deleteTask(mCurrentTask);
                Intent mFoldersIntent = mContext.getIntent();
                mContext.finish();
                mContext.startActivity(mFoldersIntent);
            }
        });
        return rowView;
    };
}





