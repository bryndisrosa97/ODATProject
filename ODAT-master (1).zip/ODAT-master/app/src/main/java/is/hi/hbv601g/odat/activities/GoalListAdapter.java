package is.hi.hbv601g.odat.activities;

import android.app.Activity;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;

import androidx.room.Room;

import java.util.ArrayList;

import is.hi.hbv601g.odat.ODATDatabase;
import is.hi.hbv601g.odat.R;
import is.hi.hbv601g.odat.entities.Goal;

public class GoalListAdapter extends ArrayAdapter {

    private final Activity mContext;
    private ArrayList<String> mNameOfTask;
    private static ODATDatabase mODATDatabase;
    private ArrayList<Goal> mGoal;

    public GoalListAdapter(Activity context, ArrayList<String> nameOfTask, ArrayList<Goal> goal) {
        super(context, R.layout.goallist, nameOfTask);
        this.mContext = context;
        this.mNameOfTask = nameOfTask;
        this.mGoal = goal;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View view, ViewGroup parent) {
        LayoutInflater inflater = mContext.getLayoutInflater();
        View rowView = inflater.inflate(R.layout.goallist, null, false);

        mODATDatabase = Room.databaseBuilder(mContext.getApplicationContext(), ODATDatabase.class, "ODAT").allowMainThreadQueries().build();

        TextView titleText = (TextView) rowView.findViewById(R.id.title);
        Button mDeleteGoalButton = (Button) rowView.findViewById(R.id.delete_goal_button);

        String mNameOfTaskString =  mNameOfTask.get(position);
        Goal mCurrentGoal = mGoal.get(position);

        titleText.setText(mNameOfTaskString);
        mDeleteGoalButton.setBackground(mContext.getResources().getDrawable(R.drawable.delete));

        mDeleteGoalButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mODATDatabase.mGoalDao().deleteGoal(mCurrentGoal);
                Intent mFoldersIntent = mContext.getIntent();
                mContext.finish();
                mContext.startActivity(mFoldersIntent);
            }
        });
        return rowView;
    };
}







