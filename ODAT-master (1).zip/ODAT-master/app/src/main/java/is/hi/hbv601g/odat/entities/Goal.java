package is.hi.hbv601g.odat.entities;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity (tableName = "goals")
public class Goal {

    @PrimaryKey (autoGenerate = true)
    private int id;

    @ColumnInfo (name = "description")
    private String mDescription;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDescription() {
        return mDescription;
    }

    public void setDescription(String description) {
        mDescription = description;
    }
}
