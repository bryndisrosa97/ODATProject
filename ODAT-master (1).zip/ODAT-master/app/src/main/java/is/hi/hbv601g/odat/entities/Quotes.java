package is.hi.hbv601g.odat.entities;

public class Quotes {
    private int mImage;
    private String mQuotes;

    public int getmImage() {
        return mImage;
    }

    public String getmQuotes() {
        return mQuotes;
    }

    public Quotes(int mImage, String mQuotes) {
        this.mImage = mImage;
        this.mQuotes = mQuotes;
    }
}
