package is.hi.hbv601g.odat.entities;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.PrimaryKey;

@Entity (tableName = "tasks",
        foreignKeys = {@ForeignKey(entity = TFolder.class,
                parentColumns = "mFolderName",
                childColumns = "folder_name",
                onDelete = ForeignKey.CASCADE)
        })
public class Task {

    @PrimaryKey (autoGenerate = true)
    private int id;

    @NonNull
    @ColumnInfo (name = "taskTitle")
    private String mTitle;

    @NonNull
    @ColumnInfo (name = "startTime")
    private String mStartTime;

    @NonNull
    @ColumnInfo (name = "endTime")
    private String mEndTime;

    @NonNull
    @ColumnInfo (name = "folder_name")
    private String mFolderName;

    @ColumnInfo (name = "notification")
    private String mNotification;

    @ColumnInfo (name = "repeat_notification")
    private String mRepeatNotification;

    public int getId() { return id; }

    public void setId(int id) { this.id = id; }

    public String getTitle() { return mTitle; }

    public void setTitle(String title) { mTitle = title; }

    public String getStartTime() { return mStartTime; }

    public void setStartTime(String startTime) { mStartTime = startTime; }

    public String getEndTime() { return mEndTime; }

    public void setEndTime(String endTime) { mEndTime = endTime; }

    public String getFolderName() { return mFolderName; }

    public void setFolderName(String folderName) { mFolderName = folderName; }

    public String getNotification() { return mNotification; }

    public void setNotification(String notification) { mNotification = notification; }

    public String getRepeatNotification() { return mRepeatNotification; }

    public void setRepeatNotification(String repeatNotification) { mRepeatNotification = repeatNotification; }
}
