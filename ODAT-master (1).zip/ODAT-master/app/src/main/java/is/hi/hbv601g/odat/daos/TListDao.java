package is.hi.hbv601g.odat.daos;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

import is.hi.hbv601g.odat.entities.TList;

@Dao
public interface TListDao {

    @Insert
    public void addTList(TList tlist);

    @Delete
    public void deleteTList(TList tList);

    @Query("SELECT * FROM lists")
    public List<TList> getAllTLists();

    @Query("SELECT * FROM lists " + "WHERE id LIKE :listId")
    public TList getListById(int listId);


}
